﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Interface1
{
    public partial class Frm_DKYuser : Form
    {

        public Frm_DKYuser()
        {
            InitializeComponent();
        }

        private void btn_exitDKY_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
